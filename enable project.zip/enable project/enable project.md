# ENABLE - Team 26 Research Project

**University of Bradford | AIRE Group | March 2026**

## Team Members
- Mohammed Ali - amoham96@bradford.ac.uk
- Hassan Raza - h.raza@bradford.ac.uk
- Aarij Javed - Ajaved46@bradford.ac.uk
- Hammad Chughtai - h.chughta@bradford.ac.uk
- Ahmed Rawa - r.ahmad60@bradford.ac.uk

## Supervisors
- Prof. CD Neagu - c.d.neagu@bradford.ac.uk
- Dr. Elaine Brown - e.brown@bradford.ac.uk

## Folders
- `/Research` - Literature review, gap analysis
- `/Proposal` - Project proposal, requirements
- `/Minutes` - Meeting notes
- `/NDA` - NDA confirmation
- `/Deliverables` - Submission info