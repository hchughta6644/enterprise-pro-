# Literature Review

## Key Sources
- OECD Digital Education Outlook 2024
- Read&Write, Goblin Tools, MindGenius analysis
- WCAG 2.1 guidelines

## Key Findings
- 15-20% of population is neurodivergent
- Current tools lack integration with university systems
- AI can help with content simplification
- Students need adaptive experiences

## Gaps Identified
- No single solution integrates all features
- University intranets lack accessibility options
- Tools not connected to LMS